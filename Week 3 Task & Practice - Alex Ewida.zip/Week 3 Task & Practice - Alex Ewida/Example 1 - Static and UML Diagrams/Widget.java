// Widget Class

public class Widget {
    private int count;
    private int color;
    // Constructor
    public Widget() {
        // Initialize as needed
    }

    // Other methods
    public void draw() {
        // Implementation for draw
    }

    public int getCount() {
        return count;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int aColor) {
        color = aColor;
    }
}