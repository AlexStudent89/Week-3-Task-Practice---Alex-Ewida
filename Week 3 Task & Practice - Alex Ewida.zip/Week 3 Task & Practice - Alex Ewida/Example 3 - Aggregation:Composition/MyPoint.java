// MyPoint Class
public class MyPoint {
    private int x;
    private int y;

    // Constructors
    public MyPoint() {
        // Default constructor
    }

    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getters and Setters
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    // Other methods
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String toString() {
        return "(" + x + "," + y + ")";
    }

    public double distance(int x, int y) {
        // Implementation for distance calculation
        return 0.0; // Replace with actual calculation
    }

    public double distance(MyPoint another) {
        // Implementation for distance calculation
        return 0.0; // Replace with actual calculation
    }

    public double distance() {
        // Implementation for distance calculation from origin
        return 0.0; // Replace with actual calculation
    }
}